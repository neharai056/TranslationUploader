# SF Translation Workbench (Chrome Extension)

Side-panel tool to view/edit Custom Label and Validation Rule translations
across every enabled Translation Workbench language, without leaving the
browser or writing any Apex.

## 1. Architecture

```
┌─────────────────────────────────────────────────────────┐
│ Side Panel (sidepanel.html/js) — single screen, 2 tabs   │
│  Tab 1: Custom Labels      Tab 2: Validation Rules        │
└───────────────┬───────────────────────┬──────────────────┘
                 │                       │
        ToolingApi.js              MetadataApi.js
     (Tooling API REST,          (Metadata API SOAP:
      fetch + Bearer token)       retrieve/deploy/listMetadata,
                 │                 via JSZip for zip payloads)
                 │                       │
        ExternalString /          Translations metadata
        ExternalStringLocalization (<lang>.translation, validationRules node)
```

Session comes from `chrome.cookies.get()` reading the active tab's `sid`
cookie (see `lib/sfSession.js`) — no OAuth app, no connected app setup,
no client id/secret to manage. This only works while you have the target
org open and logged in in the active browser tab.

### Why two APIs, same as any Salesforce translation tooling would need
- **Custom Labels** are real Tooling API sObjects (`ExternalString` /
  `ExternalStringLocalization`) — plain REST, synchronous, no deploy.
- **Validation rule error-message translations** only exist inside the
  `Translations` metadata bundle — there's no Tooling sObject for them,
  so that tab does an async Metadata API `retrieve()` → merge the
  `<validationRules>` XML node → `deploy()`, preserving every other node
  in that language's file untouched.

Because this runs in plain JS (not Apex), the SOAP envelopes for
`listMetadata` / `retrieve` / `checkRetrieveStatus` / `deploy` /
`checkDeployStatus` are just built as template strings and parsed with
`DOMParser` — no WSDL2Apex step is needed here (that was an Apex-specific
requirement from the LWC/Apex version of this tool).

## 2. Required third-party dependency: JSZip

Manifest V3's content security policy blocks remotely-loaded scripts, so
JSZip must be vendored locally rather than pulled from a CDN `<script>`
tag. Grab the official minified build and drop it in:

```
lib/jszip.min.js
```

Download: `https://github.com/Stuk/jszip/releases` → latest release →
`dist/jszip.min.js` (or `npm i jszip` and copy `node_modules/jszip/dist/jszip.min.js`).
Pin a specific version for reproducible builds rather than always
grabbing "latest." This project was built against the 3.x API
(`JSZip.loadAsync`, `zip.generateAsync`, `zip.file()`), which has been
stable across the 3.x line.

I did not paste JSZip's minified source into this deliverable — it's a
large, third-party-maintained file, and hand-transcribing minified code
from memory risks silently shipping a broken/corrupted build. Same
reasoning as depending on `MetadataService.cls`/`Zippex.cls` in the
Apex/LWC version of this tool: vendor the real, official artifact rather
than a reconstruction.

## 3. Install (unpacked, for internal/admin use)

1. Add `lib/jszip.min.js` as described above.
2. Go to `chrome://extensions`, enable **Developer mode** (top right).
3. Click **Load unpacked**, select the `sf-translation-ext` folder.
4. Pin the extension, open your Salesforce org in a tab, click the
   extension icon — the side panel opens.

## 4. Known limitations / things to verify before rolling out broadly

- **Custom domains**: `host_permissions` covers `*.salesforce.com`,
  `*.force.com`, `*.my.salesforce.com`, `*.lightning.force.com`,
  `*.visualforce.com`, `*.cloudforce.com` (sandboxes). An org on a fully
  vanity Enhanced Domain that doesn't resolve through one of those
  suffixes will need an extra host permission entry added to
  `manifest.json`.
- **`sid` cookie visibility**: if the org enforces a session security
  policy that scopes the session cookie more restrictively, or the user
  has third-party/first-party cookie blocking extensions that also
  intercept `chrome.cookies`, session detection can fail — the panel
  surfaces this as an explicit error rather than failing silently.
- **Concurrent edits**: the Validation Rules save path re-retrieves the
  language file immediately before merging/deploying (see
  `sidepanel.js`) to shrink the race window with another admin editing
  the same file, but Metadata API deploy has no optimistic-locking
  primitive — last deploy wins, same as Setup UI behavior.
- **Deploy latency**: validation rule saves are asynchronous
  (retrieve+deploy), typically a few seconds; the UI shows status text
  through each phase rather than a fixed spinner.
- This extension calls the API **with the permissions of whoever is
  logged into the active tab** — it inherits their access, it does not
  elevate it. Treat distributing this extension the same as distributing
  any tool with Setup access: restrict to trusted admins.
